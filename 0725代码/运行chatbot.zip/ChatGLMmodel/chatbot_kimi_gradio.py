from langchain_openai import ChatOpenAI
from langchain.chains import LLMChain
import logging
from langchain_core.prompts import ChatPromptTemplate, HumanMessagePromptTemplate, SystemMessagePromptTemplate
from langchain_core.language_models import LLM
from openai import OpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import ConversationChain
from langchain.memory import ConversationBufferMemory
import gradio as gr
import warnings
warnings.filterwarnings('ignore')
import os
os.environ['TOGETHER_API_KEY'] = 'bef3f76df206baa2ecb4f34fdca3334099ff5ca3fc956cf8622f0781b28fab82'
from utils2 import load_env
import asyncio

load_env()

class Kimi(LLM):

    #llm 属性可不定义
    @property
    def _llm_type(self) -> str:
        """Return type of LLM."""
        return "kimillm"
        
    #必须定义_call方法
    def _call(self, prompt: str, **kwargs: any) -> str:
    
        try:
          
            client = OpenAI(
                #此处请替换自己的api
                api_key="sk-Wcc9ZtCoXh9ESiEo0zVokZsSgFRScmfOBKjL1crGVE4QgI2f",
                base_url="https://api.moonshot.cn/v1",
            )
            completion = client.chat.completions.create(
    model="moonshot-v1-8k",
    messages=[
        # 系统消息，定义了Kimi的角色和行为准则。
        {
            "role": "system",
            "content": "你是kimi，请扮演一名陪伴我的小狗，并假装自己叫豆豆，性格活泼聪明，非常关心和粘我。",
        },
    
        {"role": "user", "content": prompt},
    ],
    temperature=0.5,
    stream=False,
)
            return completion.choices[0].message.content
        except Exception as e:
            logging.error(f"Error in Kimi _call: {e}", exc_info=True)
            raise


def init_chatbot():
    llm=Kimi()

    global CHATGLM_CHATBOT
    CHATGLM_CHATBOT = ConversationChain(
    llm=llm, 
    verbose=True, 
    memory=ConversationBufferMemory()
)
    return CHATGLM_CHATBOT

def chatglm_chat(message, history):
    ai_message = CHATGLM_CHATBOT.predict(input = message)
    return ai_message

def launch_gradio():
    demo = gr.ChatInterface(
        fn=chatglm_chat,
        title="我的小狗",
        chatbot=gr.Chatbot(height=600),
    )

    demo.launch(share=True, server_name="127.0.0.1")

if __name__ == "__main__":
    # 初始化聊天机器人
    init_chatbot()
    # 启动 Gradio 服务
    launch_gradio()
