# 导入所需的库
import os
import platform
import signal
from transformers import AutoTokenizer, AutoModel
import readline

# 从预训练模型路径加载tokenizer和模型
tokenizer = AutoTokenizer.from_pretrained('model6b', trust_remote_code=True)
model = AutoModel.from_pretrained('model6b', trust_remote_code=True).half().to('mps')
# 用来将模型加载到GPU上的。如果像我一样是mac，不使用gpu推理时，使用mps。⬆️
# model = AutoModel.from_pretrained("model6b", trust_remote_code=True).half().cuda()
model = model.eval()  # 将模型设置为评估模式

# 获取操作系统名称，以确定清屏命令
os_name = platform.system()
clear_command = 'cls' if os_name == 'Windows' else 'clear'
stop_stream = False  # 用于控制流的全局变量

# 构建提示信息的函数
def build_prompt(history):
    prompt = "欢迎使用 ChatGLM-6B 模型，输入内容即可进行对话，clear 清空对话历史，stop 终止程序"
    for query, response in history:
        prompt += f"\n\n用户：{query}"
        prompt += f"\n\nChatGLM-6B：{response}"
    return prompt

# 信号处理函数，用于处理中断信号
def signal_handler(signal, frame):
    global stop_stream
    stop_stream = True

# 主函数
def main():
    history = []  # 用于存储对话历史的列表
    global stop_stream
    print("欢迎使用 ChatGLM-6B 模型，输入内容即可进行对话，clear 清空对话历史，stop 终止程序")
    while True:  # 无限循环，直到用户输入'stop'
        query = input("\n用户：")  # 获取用户输入
        if query.strip() == "stop":
            break  # 如果用户输入'stop'，则退出循环
        if query.strip() == "clear":
            history = []  # 清空对话历史
            os.system(clear_command)  # 清屏
            print("欢迎使用 ChatGLM-6B 模型，输入内容即可进行对话，clear 清空对话历史，stop 终止程序")
            continue  # 继续下一轮循环
        count = 0
        for response, history in model.stream_chat(tokenizer, query, history=history):
            if stop_stream:
                stop_stream = False
                break
            else:
                count += 1
                if count % 8 == 0:
                    os.system(clear_command)  # 每8次循环清屏一次
                    print(build_prompt(history), flush=True)  # 打印构建的提示信息
                    signal.signal(signal.SIGINT, signal_handler)  # 设置信号处理函数
        os.system(clear_command)  # 清屏
        print(build_prompt(history), flush=True)  # 打印最终的对话历史

# 程序入口点
if __name__ == "__main__":
    main()