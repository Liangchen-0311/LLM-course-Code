from langchain_openai import ChatOpenAI
from langchain.chains import LLMChain
import logging
from langchain_core.prompts import ChatPromptTemplate, HumanMessagePromptTemplate, SystemMessagePromptTemplate
from langchain_core.language_models import LLM
from openai import OpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import ConversationChain
from langchain.memory import ConversationBufferMemory
import gradio as gr


# ++++++++++++
class Kimi(LLM):

    #llm 属性可不定义
    @property
    def _llm_type(self) -> str:
        """Return type of LLM."""
        return "kimillm"
        
    #必须定义_call方法
    def _call(self, prompt: str, **kwargs: any) -> str:
    
        try:
          
            client = OpenAI(
                #此处请替换自己的api
                api_key="sk-OjgMJ2Elq1ESnh5PUwIlnYlfK0wkk4jICQRj7Z0itKA1eLVd",
                base_url="https://api.moonshot.cn/v1",
            )
            completion = client.chat.completions.create(
    model="moonshot-v1-8k",
    messages=[
        # 系统消息，定义了Kimi的角色和行为准则。
        {
            "role": "system",
            "content": "你是kimi，请假装自己叫小课，是一名专业的大模型学者，用简单轻松的语言帮助我理解AI学习过程中的概念。",
        },
    
        {"role": "user", "content": prompt},
    ],
    temperature=0.1,
    stream=False,
)
            return completion.choices[0].message.content
        except Exception as e:
            logging.error(f"Error in Kimi _call: {e}", exc_info=True)
            raise

# 使用kimi定义model的话需定义


def init_chatbot():
    llm=Kimi()

    global CHATGLM_CHATBOT
    CHATGLM_CHATBOT = ConversationChain(
    llm=llm, 
    verbose=True, 
    memory=ConversationBufferMemory()
)
    return CHATGLM_CHATBOT

def chatglm_chat(message, history):
    ai_message = CHATGLM_CHATBOT.predict(input = message)
    return ai_message

def launch_gradio():
    demo = gr.ChatInterface(
        fn=chatglm_chat,
        title="AI学习助手",
        chatbot=gr.Chatbot(height=600),
    )

    demo.launch(share=True, server_name="0.0.0.0")

if __name__ == "__main__":
    # 初始化聊天机器人
    init_chatbot()
    # 启动 Gradio 服务
    launch_gradio()
