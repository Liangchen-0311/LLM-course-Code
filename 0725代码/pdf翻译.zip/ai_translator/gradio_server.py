import sys
import os
import gradio as gr

# 将当前文件的目录添加到系统路径中，以便可以导入同一目录下的其他模块
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from utils import ArgumentParser, LOG
from translator import PDFTranslator, TranslationConfig

# 定义翻译函数，接受输入文件、源语言和目标语言作为参数
def translation(input_file, source_language, target_language):
    # 使用LOG对象记录一条调试信息，显示翻译任务的详细信息
    LOG.debug(f"[翻译任务]\n源文件: {input_file.name}\n源语言: {source_language}\n目标语言: {target_language}")
        # 初始化配置单例
    argument_parser = ArgumentParser()
    args = argument_parser.parse_arguments()
    config = TranslationConfig()
    config.initialize(args)  
    # 调用Translator实例的translate_pdf方法进行翻译，并将结果保存到output_file_path变量中
    output_file_path = Translator.translate_pdf(
        input_file.name, source_language=source_language, target_language=target_language)
    # output_file_path = Translator.translate_pdf(config.input_file, config.output_file_format, pages=None)
    # 函数返回翻译后的文件路径
    return output_file_path

# 定义启动Gradio界面的函数
def launch_gradio():
    # 创建Gradio界面，指定翻译函数为处理函数
    iface = gr.Interface(
        fn=translation,
        title="OpenAI-Translator v2.0(PDF 电子书翻译工具)",
        inputs=[
            gr.File(label="上传PDF文件"),  # 输入项1：上传PDF文件
            gr.Textbox(label="源语言（默认：英文）", placeholder="English", value="English"),  # 输入项2：源语言
            gr.Textbox(label="目标语言（默认：中文）", placeholder="Chinese", value="Chinese")  # 输入项3：目标语言
        ],
        outputs=[
            gr.File(label="下载翻译文件")  # 输出项：下载翻译后的文件
        ],
        allow_flagging="never"  # 设置不允许标记不当内容
    )

    # 启动Gradio界面，允许共享，并指定服务器名称为0.0.0.0（即对所有网络接口可见）
    iface.launch(share=True, server_name="0.0.0.0")

# 定义初始化翻译器的函数
def initialize_translator():
    # 解析命令行参数
    argument_parser = ArgumentParser()
    args = argument_parser.parse_arguments()

    # 初始化配置单例
    config = TranslationConfig()
    config.initialize(args)    
    # 实例化PDFTranslator类，并调用translate_pdf方法
    global Translator
    Translator = PDFTranslator(config.model_name)
    # Translator.translate_pdf(config.input_file, config.output_file_format, pages=None)

# 程序入口点
if __name__ == "__main__":
    # 初始化translator
    initialize_translator()
    # 启动Gradio服务
    launch_gradio()