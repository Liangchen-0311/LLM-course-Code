import sys
import os

# 将当前文件的目录添加到系统路径中，以便可以导入同一目录下的其他模块
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from flask import Flask, request, send_file, jsonify
from translator import PDFTranslator, TranslationConfig
from utils import ArgumentParser, LOG

# 创建 Flask 应用实例
app = Flask(__name__)

# 定义临时文件目录
TEMP_FILE_DIR = "flask_temps/"

# 定义 '/translation' 路由的处理函数，接受 POST 请求
@app.route('/translation', methods=['POST'])
def translation():
    try:
        # 从请求中获取上传的文件
        input_file = request.files['input_file']
        # 从请求表单中获取源语言和目标语言，默认分别为英文和中文
        source_language = request.form.get('source_language', 'English')
        target_language = request.form.get('target_language', 'Chinese')

        # 记录输入文件信息
        LOG.debug(f"[input_file]\n{input_file}")
        LOG.debug(f"[input_file.filename]\n{input_file.filename}")

        # 检查文件是否存在且有文件名
        if input_file and input_file.filename:
            # 创建临时文件路径
            input_file_path = TEMP_FILE_DIR+input_file.filename
            LOG.debug(f"[input_file_path]\n{input_file_path}")

            # 保存上传的文件到临时路径
            input_file.save(input_file_path)

            # 调用翻译函数进行翻译
            output_file_path = Translator.translate_pdf(
                input_file=input_file_path,
                source_language=source_language,
                target_language=target_language)
            
            # 移除临时文件
            # os.remove(input_file_path)

            # 构造完整的输出文件路径
            # output